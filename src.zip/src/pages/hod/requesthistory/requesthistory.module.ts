import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { RequesthistoryPage } from './requesthistory';

@NgModule({
  declarations: [
    RequesthistoryPage,
  ],
  imports: [
    IonicPageModule.forChild(RequesthistoryPage),
  ],
})
export class RequesthistoryPageModule {}
