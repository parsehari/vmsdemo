import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { HoddashboardPage } from '../hod/hoddashboard/hoddashboard';
import { EmpdashboardPage } from '../employee/empdashboard/empdashboard';
import { DriverPage } from '../driver/driver';
import { LoginPage } from '../login/login';
import { ServiceProvider } from '../../providers/service/service';
import { CommonProvider } from '../../providers/common/common';
import { QRScanner, QRScannerStatus } from '@ionic-native/qr-scanner';
/**
 * Generated class for the UsersDashboardPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-users-dashboard',
  templateUrl: 'users-dashboard.html',
})
export class UsersDashboardPage {
  userDetails: any = [];
  driverMobileNumber: any = '';
  securityCheck: any = '';

  constructor(public navCtrl: NavController,
              public navParams: NavParams,
              public commonProvider: CommonProvider,
              public serviceProvider: ServiceProvider,
              public qrScanner: QRScanner
   ) {
    //this.userDetails = navParams.data.response.EmployeeDetail;
    console.log("in user page ", navParams);
    console.log("navParams.get('driverNumber') ", navParams.get('driverNumber'));
    console.log("navParams.get('securitylogin') ", navParams.get('security'));
    if(navParams.get('driverNumber')){
       this.driverMobileNumber = navParams.get('driverNumber');
    }else if(navParams.get('security')){
      this.securityCheck = navParams.get('security');
    }else{
      this.userDetails = navParams.data.response.EmployeeDetail;
    }

  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad UsersDashboardPage');
  }
  showDashboard(){
      //this.navCtrl.push('EmpdashboardPage',{ 'EmployeeDetail': this.userDetails });
    this.navCtrl.push('HoddashboardPage',{ 'EmployeeDetail': this.userDetails });
  }
  getTripDetails(status: any){
    this.navCtrl.push('DriverPage',{'pageOpen': status});
  }

 securityScan(ev){
   this.qrScanner.prepare()
  .then((status: QRScannerStatus) => {
     if (status.authorized) {
       // camera permission was granted


       // start scanning
       let scanSub = this.qrScanner.scan().subscribe((text: string) => {
         console.log('Scanned something', text);

         this.qrScanner.hide(); // hide camera preview
         scanSub.unsubscribe(); // stop scanning
       });

     } else if (status.denied) {
       console.log("permission is denied");
       // camera permission was permanently denied
       // you must use QRScanner.openSettings() method to guide the user to the settings page
       // then they can grant the permission from there
     } else {
       // permission was denied, but not permanently. You can ask for permission again at a later time.
     }
  })
  .catch((e: any) => this.commonProvider.showToast(e));
 }

  // logout(){
  //   this.commonProvider.Alert.confirm('Sure you want to logout?').then((res) => {
  //     this.nativeStorage.remove('userData');
  //   this.navCtrl.setRoot(LoginPage,{});
  // },err=>{
  //   console.log('user cancelled');
  // })
  // }

}
